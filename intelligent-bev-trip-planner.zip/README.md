# 🚗 Intelligent Trip Planning for Battery Electric Vehicles (BEVs) Using Real-Time Simulation in MATLAB

This project simulates an intelligent trip planner for Battery Electric Vehicles using MATLAB. It calculates energy consumption based on route characteristics and optimizes paths based on cost and battery capacity.

## 🧠 Features
- Vehicle energy consumption modeling
- Route optimization using graph-based logic
- Battery management logic
- Ready for integration with real-time data and Simulink models

## 📁 Repository Structure
```
code/               # MATLAB scripts for simulation
simulink_models/    # Simulink models for EV simulation (optional)
data/               # Example datasets or generated values
results/            # Output logs or plots
docs/               # Diagrams or presentation materials
```

## 🧾 Requirements
- MATLAB R2021b or later
- Simulink (optional for system modeling)

## 🚀 How to Run
1. Clone the repository:
   ```
   git clone https://github.com/<your-username>/intelligent-bev-trip-planner.git
   cd intelligent-bev-trip-planner/code
   ```

2. Open MATLAB and run:
   ```matlab
   run_all.m
   ```

3. (Optional) Open Simulink model:
   ```
   simulink_models/ev_simulink_model.slx
   ```

## 📌 Future Scope
- Integration with Google Maps API
- Dynamic traffic-aware routing
- Machine learning for driving pattern prediction

## 📄 License
MIT License

## 👨‍💻 Contributors
- Krish Sabarwal
- Your teammates (add names)
