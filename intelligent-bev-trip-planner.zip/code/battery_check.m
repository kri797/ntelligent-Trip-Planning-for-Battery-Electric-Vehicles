% Battery management logic
battery_capacity = 50;
state_of_charge = 40;
trip_energy_required = 18;

if trip_energy_required > state_of_charge
    disp('Trip not possible without charging.');
else
    disp('Trip is possible without charging.');
end
