% Energy consumption calculation
mass = 1500;
drag_coeff = 0.29;
frontal_area = 2.2;
air_density = 1.225;
rolling_resistance = 0.015;
g = 9.81;

speed = 60 / 3.6;
distance = 10000;
elevation_gain = 100;

F_drag = 0.5 * drag_coeff * frontal_area * air_density * speed^2;
F_roll = rolling_resistance * mass * g;
F_gravity = mass * g * (elevation_gain / distance);

total_force = F_drag + F_roll + F_gravity;
work = total_force * distance;
energy_consumed_kWh = work / 3.6e6;

fprintf('Estimated energy consumption: %.2f kWh\n', energy_consumed_kWh);
