% Run all modules
disp('Running energy model...');
run('energy_model.m');

disp('Running route optimization...');
run('route_optimization.m');

disp('Running battery check...');
run('battery_check.m');
