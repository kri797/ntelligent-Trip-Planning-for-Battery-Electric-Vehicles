% Route optimization using graph logic
G = digraph();
G = addedge(G, 1, 2, 50);
G = addedge(G, 2, 3, 40);
G = addedge(G, 1, 4, 70);
G = addedge(G, 4, 3, 30);
G = addedge(G, 3, 5, 60);
G = addedge(G, 4, 5, 90);

[path, total_cost] = shortestpath(G, 1, 5);
fprintf('Optimal route: %s\n', mat2str(path));
fprintf('Total estimated cost: %.2f km\n', total_cost);
